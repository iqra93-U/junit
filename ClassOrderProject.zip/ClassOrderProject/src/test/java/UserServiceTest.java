import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

@Order(2)
public class UserServiceTest {

    @BeforeAll
    static void setUp() {
        System.out.println("Test methods related to User service");
    }

    @Test
    void testCreateUser_whenUserTitleIsMissing_throwsOrderServiceException() {

    }


}
