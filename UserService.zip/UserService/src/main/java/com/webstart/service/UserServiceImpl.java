package com.webstart.service;

import com.webstart.model.User;

import java.util.UUID;

public class UserServiceImpl implements UserService {

    @Override
    public User createUser(String firstName, String lastName, String email, String password, String repeatedPassword) {

        // 8 - Pour faire fonctionner la fonction vous retournerez un Uservide()
        // return new User();

        // 13
        // return new User(firstName, lastName, email);

        // 20 -

        if(firstName == null || firstName.trim().length() == 0) {
            throw new IllegalArgumentException("User's firstName is empty");
        }

        return new User(firstName, lastName, email, UUID.randomUUID().toString());
    }

}
