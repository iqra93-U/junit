import com.webstart.model.User;
import com.webstart.service.UserService;
import com.webstart.service.UserServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class UserServiceTest {

    // 22 - Pour empécher la duplication du code
    UserService userService;
    String firstName;
    String lastName;
    String email;
    String password;
    String repeatedPassword;

    @BeforeEach
    void init() {
        userService = new UserServiceImpl();

        firstName = "Samih";
        lastName = "Habbani";
        email = "test@gmail.com";
        password = "1234";
        repeatedPassword = "1234";
    }

    // 22 - Faudra ensuite refactorisé le code ci-dessous et laisser que le code dont on a besoin

    @DisplayName("User Object created")// 15
    @Test
    void testCreateUser_whenUserDetailsProvided_returnUserObject() {

        // 1 - On commence par définir la méthode de test

        // Arrange
        // 2 - on va avoir besoin d'un service
        UserService userService = new UserServiceImpl(); // 3 - Faut créer maintenant le service et son interface

        // 5 - Préparation des données + ajouter ces paramètres à la méthode de l'interface et la méthode createUser
        String firstName = "Samih";
        String lastName = "Habbani";
        String email = "test@gmail.com";
        String password = "1234";
        String repeatedPassword = "1234";

        // Act
        // 6 - je variabilise le retour de la fonction et j'attend un objet de type User donc va falloir créer l'entité
        // 7 - maintenant la méthode createUser doit nous retourner un objet de type User
        // donc on doit mettre à jour encore une fois l'interface et le service
        User user = userService.createUser(firstName, lastName, email, password, repeatedPassword); // 4 - Create user method dans interface et service

        // Assert
        // 9 - Maintenant on peut s'assurer que je récupère bien quelque chose
        assertNotNull(user, "The createUser() method should not return null");
        // 14 - Prochaine étape : refactorisation
        assertEquals(firstName, user.getFirstName(), "User firstName should not be different");


    }

    // 10 - test user object contains firstName
    @Test
    void testCreateUser_whenUserCreated_returnedUserObjectContainsSameFirstName() {

        UserService userService = new UserServiceImpl();

        String firstName = "Samih";
        String lastName = "Habbani";
        String email = "test@gmail.com";
        String password = "1234";
        String repeatedPassword = "1234";

        // Act
        User user = userService.createUser(firstName, lastName, email, password, repeatedPassword);

        // Assert
        // 11 - Pour s'assurer que le prénom du user est celui setté faut encapsuler un nouvel attribut firstName
        // avec son getter dans User
        // la méthode user.getFirstName() nous renvoit null
        // donc la méthode de test fail
        // c'est parcequ'on ne retourne pas un user pour lequel on a initialisé des valeurs
        // 12 - Mettre en place un constructeur pour initialiser un firstName dans mon User
        // 13 - Dans notre serviceImpl, quand on retourn un objet User faudra passer au constructure le firstName passé en paramètre
        // Le test passe maintenant

        // 14 - Prochaine étape : refactorisation
        // Ici notre code est redondant on peut le couper coller le assertEquals et le copier dans la méthode du dessus
        // ça fera le même effet

        // On a implémenter notre code step by step en commençant par les tests unitaires
        // ça permet d'avoir un code plus propre et refactoriser plus facilement le code

        // 15 - AJouter maintenant un displayName() à la méthode du dessus et vérifier que tout continuer de fonctionner
        assertEquals(firstName, user.getFirstName(), "User firstName should not be different");

        // 16 - verify that user object contains lastName et email adress - se baser sur ce qui a été fait avant !
        assertEquals(lastName, user.getLastName(), "User firstName should not be different");
        assertEquals(email, user.getEmail(), "User firstName should not be different");

        // 17 - check if user id is set
        // En général one strong assertion per method
        // Ci-dessous on a mis plusieurs assertions dans la même méthode car ils tcheck le même objet
        // on peut donc ajouter la vérification sur l'id sur notre user
        assertNotNull(user.getId(), "user id is missing"); // faudra donc mettre à jour le modèle User
        // La méthode fail car j'ai besoin d'ajouter l'id lors de la création du user dans le serviceImpl
        // Pour rappel : Tout ce code devrait se retrouver dans la méthode du dessus

    }

    // 18 - Assert exception is one information is missing
    // let's write test code first
    // On veut s'assurer que si je ne renseigne pas de firstName
    // je recois une illegal Exception

    @DisplayName("Empty firstName causes correct exception")
    @Test
    void testCreateUser_whenFirstNameIsEmpty_throwsIlligalArgumentException() {

        // Arrange
        UserService userService = new UserServiceImpl();

        String firstName = ""; // firstName should be empty
        String lastName = "Habbani";
        String email = "test@gmail.com";
        String password = "1234";
        String repeatedPassword = "1234";

        // Act & Assert
        IllegalArgumentException thrown = Assertions.assertThrows(IllegalArgumentException.class, () -> {
            // 20 - Le test va fail car faut implémenter les changement dans UserServiceImpl
            userService.createUser(firstName, lastName, email, password, repeatedPassword);
        }, "Empty first Name sould have caused and Illegal Argument Exception");

        // 21 - Assert that the message we receive is the one we expect
        String expectedException = "User's firstName is empty";
        assertEquals(expectedException, thrown.getMessage(), "Exception error message is not correct!");

        // 22 - Si je regarde testCreateUser_whenFirstNameIsEmpty_throwsIlligalArgumentException and testCreateUser_whenUserDetailsProvided_returnUserObject
        // They use the same data
        // je peux refactoriser et empécher la duplication du code dans un @BeforeEach et supprimer les jeux de données dupliqués :)
    }


}
