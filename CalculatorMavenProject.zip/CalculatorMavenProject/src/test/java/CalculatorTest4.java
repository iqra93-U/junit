import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

// JUnit Test Lifecycle

@DisplayName("Tests Math operations in Calculator Class")
public class CalculatorTest4 {

    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Executing @BeforeAll method");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("Executing @AfterAll method");
    }

    @BeforeEach
    void beforeEachTestMethod() {
        calculator = new Calculator();
        System.out.println("Executing @BeforeEach method");
    }

    @AfterEach
    void afterEachTestMethod() {
        System.out.println("Executing @AfterEach method");
    }

    @DisplayName("Test 4/2 = 2")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo() {

        System.out.println("Running 4/2 = 2");
        // Assert Pattern
        // Arrange
        int number1 = 4;
        int number2 = 2;

        // Act
        int result = calculator.integerDivision(number1,number2);

        // Assert
        assertEquals(2, result, () -> number1 + "/" + number2 + " did not produce 2");

    }

    @DisplayName("Test 3 - 1 = 2")
    @Test
    void testIntegerSubstraction_When3MinusOne_ShouldReturnTwo() {

        System.out.println("Running 3 - 1 = 2");
        int number1 = 3;
        int number2 = 1;
        int result = calculator.integerSubstraction(number1 , number2);

        assertEquals(2, result, () -> number1 + "- " + number2 + " did not produce 2");
    }

    @DisplayName("Division by zero")
    @Test
    void testIntegerDivision_WhenDividendIsDividedByZero_shouldThrownArithmeticException() {

        System.out.println("Running Division by zero");

        // Arrange
        int dividend = 4;
        int divisor = 0;
        String expectedExceptionMessage = "/ by zero";

        // Act / Assert
        ArithmeticException actualException = assertThrows(
                ArithmeticException.class,
                () -> {
                    calculator.integerDivision(dividend, divisor);
                }, "Division by zero should have thrown an Arithmetic exception");

        assertEquals(expectedExceptionMessage, actualException.getMessage());

    }


    @DisplayName("Test Integer Substraction [number1, number2, expectedResult]")
    @ParameterizedTest
    @CsvSource({
         "33, 1, 32",
         "10, 4, 6",
         "27, 27, 0"
    })
    void integerSubstractionParameters(int number1, int number2, int expectedResult) {

        System.out.println("Running Test " + number1 + " - " + number2 + " = " + expectedResult);
        Calculator calculator = new Calculator();

        int result = calculator.integerSubstraction(number1 , number2);

        //assertEquals(2, result, "3-1 did not produce 2");
        assertEquals(expectedResult, result, () -> number1 + "- " + number2 + " did not produce " + expectedResult);
    }

}

