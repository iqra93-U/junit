import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Tests Math operations in Calculator Class")
public class CalculatorTest1 {

    @DisplayName("Test 4/2 = 2")
    @Test // annotation
    void integerDivision() {

        // First unit test method
        Calculator calculator = new Calculator();
        int result = calculator.integerDivision(4,2);

        // alt + entrée
        assertEquals(2, result, "4/2 did not produce 2");
        // assertNotEquals()
        // assertNull()
        // assertNotNull()
        // assertThrows()
        // assertNotThrows()
        // assertTrue()
        // assertFalse()
        // fail()
    }

    @DisplayName("Test 3 - 1 = 2")
    @Test
    void integerSubstraction() {
        Calculator calculator = new Calculator();

        int number1 = 3;
        int number2 = 1;
        int result = calculator.integerSubstraction(number1 , number2);

        //assertEquals(2, result, "3-1 did not produce 2");
        assertEquals(2, result, () -> number1 + "- " + number2 + " did not produce 2");
    }

    // Convention de nommage

    @DisplayName("Test 4/2 = 2")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo() {

        // Assert Pattern
        // Arrange
        Calculator calculator = new Calculator();
        int number1 = 4;
        int number2 = 2;

        // Act
        int result = calculator.integerDivision(number1,number2);

        // Assert
        assertEquals(2, result, () -> number1 + "/" + number2 + " did not produce 2");

    }

    @DisplayName("Test 3 - 1 = 2")
    @Test
    void testIntegerSubstraction_When3MinusOne_ShouldReturnTwo() {

    }

    @DisplayName("Division by zero")
    @Test
    void testIntegerDivision_WhenDividendIsDividedByZero_shouldThrownArithmeticException() {

    }


}

