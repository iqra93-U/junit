import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class DemoRepeatedTest {

    // @Test : regular test
    // @ParameterizedTest : exécuter la méthode test avec plusieurs jeux de données différents

    Calculator calculator;

    @BeforeEach
    void beforeEachMethod() {
        System.out.println("Executing @BeforeEach method");
        calculator = new Calculator();
    }

    @DisplayName("Division by zero")
    // @RepeatedTest(3)
    @RepeatedTest(value = 3, name="{displayName}; Repetition {currentRepetition} of {totalRepetitions}")
    void testIntegerDivision_WhenDividendIsDividedByZero_shouldThrownArithmeticException(
            RepetitionInfo repetitionInfo, // injection de dépendance
            TestInfo testInfo
    ) {

        System.out.println("Running " + testInfo.getTestMethod().get().getName());
        System.out.println("Repetition #" + repetitionInfo.getCurrentRepetition() + " of " + repetitionInfo.getTotalRepetitions());

        // Arrange
        int dividend = 4;
        int divisor = 0;
        String expectedExceptionMessage = "/ by zero";

        // Act / Assert
        ArithmeticException actualException = assertThrows(
                ArithmeticException.class,
                () -> {
                    calculator.integerDivision(dividend, divisor);
                }, "Division by zero should have thrown an Arithmetic exception");

        assertEquals(expectedExceptionMessage, actualException.getMessage());

    }

}
