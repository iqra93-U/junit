public class Calculator {

    public int integerDivision(int number1, int number2) {
        return number1 / number2;
    }

    public int integerSubstraction(int number1, int number2) {
        return number1 - number2;
    }

}
