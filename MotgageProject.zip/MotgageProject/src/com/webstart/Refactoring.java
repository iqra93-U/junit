package com.webstart;

import java.text.NumberFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Refactoring {

    final static byte MONTHS_IN_YEAR = 12;
    final static byte PERCENT = 100;

    public static void main(String[] args) {


        // Montant
        int amount = (int) readNumber("Somme principale : ", 1000, 1_000_000);

        // Taux annuel
        float annualInterest = (float) readNumber("Taux annuel d'intérêt", 1, 3);

        // Nombre de paiements
        byte years = (byte) readNumber("Nombre d'années : ", 1, 30);

        double mortgage = calculateMortgage(amount, annualInterest, years);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Votre remboursement de prêt mensuel s'élève à " + mortgageFormatted);

    }

    public static double calculateMortgage(int amount, float annualInterest, byte years) {

        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;
        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);

        double mortgage = amount
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return mortgage;

    }

    public static double readNumber(String msg, double min, double max) {

        // tant qu'ai pas une valeur comprise entre min et max
        // ou que la donnée rentrée n'est pas un double
        //je repose la question

        // si c'est pas compris entre win et max -> Veuillez entrer une valeur comprise entre min et max
        // si c'est pas un double -> veuillez rentrer une valeur numérique

        Scanner scanner = new Scanner(System.in);
        double value;

        while(true) {

            try {
                System.out.println(msg);
                value = scanner.nextDouble();

                if(value >= min && value <= max) {
                    break;
                }

                System.out.println("Veuillez entrer une valeur comprise entre " + min + " et " + max);
            } catch (InputMismatchException e) {
                System.out.println("Veuillez rentrer une valeur numérique");
            }

        }
        return value;

    }

}
