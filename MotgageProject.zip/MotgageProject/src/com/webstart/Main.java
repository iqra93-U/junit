package com.webstart;

import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;

        // Somme principale
        Scanner scanner = new Scanner(System.in);
        System.out.println("Somme principale :");
        int amount = scanner.nextInt();

        // Taux annuel
        System.out.println("Taux annuel :");
        float annualInterest = scanner.nextFloat();
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        // Nombre d'années
        System.out.println("Nombre d'années");
        byte years = scanner.nextByte();
        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);

        double mortgage = amount
                        * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                        / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Votre remboursement de prêt mensuel s'élève à " + mortgageFormatted);


    }
}
